<?php
  add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );

  function enqueue_parent_styles() {
     wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
  }
  
  /**
   * Register Widget Area.
   *
   */
  function sgc_widgets3_init() {

    register_sidebar( array(
      'name' => '3 wide Container Sidebar',
      'id' => 'wide3_sidebar',
      'before_widget' => '<div class="sgc-widget3 col-xs-12 col-sm-4 col-lg-4 ">',
      'after_widget' => '</div>',
      'before_title' => '<h2>',
      'after_title' => '</h2>',
    ) );
  }
  add_action( 'widgets_init', 'sgc_widgets3_init' );
  
  function sgc_widgets2_init() {

    register_sidebar( array(
      'name' => '2 wide Container Sidebar',
      'id' => 'wide2_sidebar',
      'before_widget' => '<div class="sgc-widget2 col-lg-6 col-sm-6 col-xs-12">',
      'after_widget' => '</div>',
      'before_title' => '<h2>',
      'after_title' => '</h2>',
    ) );
  }
  add_action( 'widgets_init', 'sgc_widgets2_init' );
  
  function sgc_widgets1_init() {

    register_sidebar( array(
      'name' => '1 wide Container Sidebar',
      'id' => 'wide1_sidebar',
      'before_widget' => '<div class="sgc-widget1">',
      'after_widget' => '</div>',
      'before_title' => '<h2>',
      'after_title' => '</h2>',
    ) );
  }
  add_action( 'widgets_init', 'sgc_widgets1_init' );
  
  add_action( 'sgc_container1_hook', 'custom_1wideContainer_widget' );
  add_action( 'sgc_container2_hook', 'custom_2wideContainer_widget' );
  add_action( 'sgc_container3_hook', 'custom_3wideContainer_widget' );
  
  function custom_1wideContainer_widget() {
    if ( is_front_page() && is_active_sidebar( 'wide1_sidebar' ) ) :
      dynamic_sidebar( 'wide1_sidebar' );
    endif;
  }
  function custom_2wideContainer_widget() {
    if ( is_front_page() && is_active_sidebar( 'wide2_sidebar' ) ) :
      dynamic_sidebar( 'wide2_sidebar' );
    endif;
  }
  function custom_3wideContainer_widget() {
    if ( is_front_page() && is_active_sidebar( 'wide3_sidebar' ) ) :
      dynamic_sidebar( 'wide3_sidebar' );
    endif;
  }