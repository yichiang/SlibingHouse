<?php

/*

Template Name: Custom Full width

*/
	get_header();
?>

	<div id="Actualprimary" class="content-area fullwidth">
		
		<div id="widgets2wide" class="row hentry">
		  <?php
			do_action( 'sgc_container2_hook' );
		  ?>
		</div>
		
		<div id="widgets3wide" class="row hentry">
		  <?php
			do_action( 'sgc_container3_hook' );
		  ?>
		</div>
		
	</div><!-- #primary -->

	<div id="primary" class="content-area">
		
		<div id="widgets1wide" class="row hentry" style="padding-top: 30px !important">
		  <?php
			do_action( 'sgc_container1_hook' );
		  ?>
		</div>
		
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
?>

