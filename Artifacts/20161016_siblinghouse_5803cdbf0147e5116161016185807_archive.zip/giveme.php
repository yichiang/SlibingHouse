<?php

 echo $_SERVER['MYSQLCONNSTR_localdb'];
?>
